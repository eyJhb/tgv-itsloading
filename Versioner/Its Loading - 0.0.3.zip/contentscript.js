$( document ).ready(function() {
	//Domæne
	var domain = (location.host.match(/([^.]+)\.\w{2,3}(?:\.\w{2})?$/) || [])[1];
	
	//Billede
	var bannerimg = chrome.extension.getURL("images/itsloading.png");
	
	//Ændre titlen på hjemmesiden
	if(domain == "itslearning")
	{ 	
		var name = document.location.href.match(/[^\/]+$/)[0];
		name = name.toLowerCase();
		$('title').text("itsloading...");
		
		if(name.indexOf("index.aspx") != -1)
		{
			var logintext = $('#ctl00_ContentPlaceHolder1_nativeAndLdapLoginWrapper').find('p[class$="h-fnt-sm"]');
			var sitelogo = $('.l-login-sitelogo');
			var sitetext = $('.h-dsp-ib');
			var footer = $('body').find('img[src$="https://statics.itslearning.com/v3.46.1.71/images/brand.png"]');
			
			logintext.html("Log på med itsloading");
			
			sitelogo.attr('src', bannerimg);
			sitelogo.css('max-height', 100);
			sitetext.html("Aarhus Tech - It's Loading...");
			
			footer.attr('src', bannerimg);
			footer.css('width', "auto");
			footer.css('height', 33);
		}
		else
		{
			var test = $('body').find('img[src$="https://statics.itslearning.com/v3.46.1.71/images/powered_by_itslearning.png"]');
			
			test.attr('src', bannerimg);
			test.css('width', "auto");
			test.css('height', 24);
			console.log("something else!");
		}
	}
	else if(domain == "aarhustech")
	{
		var learningtext = $('body').find('div[title$="Skolens læringsmiljø for studerende"]');
		
		learningtext.html('<a href="https://aarhustech.itslearning.com/elogin/" ><img alt="Skolens l&#230;ringsmilj&#248; for studerende" src="http://www.ats.dk/images/Resume_145/its_learning.gif" ><br />it\'s loading</a>');
	}
});