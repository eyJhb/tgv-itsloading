$( document ).ready(function() {
	//Domæne
	var domain = (location.host.match(/([^.]+)\.\w{2,3}(?:\.\w{2})?$/) || [])[1];
	
	//Tjekker hvilket domæne vi befinder os på
	if(domain == "itslearning")
	{	
		
		var holliday = getHolliday();
		var image = "images/itsloading.png";
		
		if(holliday == 1) {
			image = "images/itsloading-christmas.png";
		} else if (holliday == 3) {
			image = "images/itsloading-halloween.png";		
		}
		// else if(holliday == 2) {
		//	image = "images/itsloadingNEWYEAR.png";
		//}
		
		var bannerimg = chrome.extension.getURL(image);
		var otherimg = chrome.extension.getURL("images/itsloading.png");
		
		//Giver os hvilken side (/), og gør det til lowercase
		//var name = document.location.href.match(/[^\/]+$/)[0];
		if(document.location.href.match(/[^\/]+$/))
			var name = document.location.href.match(/[^\/]+$/)[0];
		else
			var name = "index.aspx";
		
		name = name.toLowerCase();
		
		
		//Ændre titlen på hjemmesiden, så længe vi befinder os på It's Learning, og titlen er 'itslearning'
		var title = $('title').text();
		title = title.trim();
		
		if(title == "itslearning") {
			$('title').text("itsloading...");
		}
		
		//Tjekker hvilke side vi er på, og laver passende aktioner.
		if(name.indexOf("index.aspx") != -1)
		{
			
			var logintext = $('#ctl00_ContentPlaceHolder1_nativeAndLdapLoginWrapper').find('p[class$="h-fnt-sm"]');
			var sitelogo = $('.l-login-sitelogo');
			var sitetext = $('.h-dsp-ib');
			var footer = $('body').find('img[src$="https://statics.itslearning.com/v3.46.1.71/images/brand.png"]');
			
			logintext.html("Log på med itsloading");
			
			sitelogo.attr('src', bannerimg);
			sitelogo.css('max-height', 100);
			sitetext.html("Aarhus Tech - It's Loading...");
			
			footer.attr('src', otherimg);
			footer.css('width', "auto");
			footer.css('height', 33);
						
		}
		else
		{
			
			$('body').find("a").each(function() {
				var link =  $(this);
				
				if($(this).attr("href"))
				{
					var linkHref = $(this).attr("href");
					
					if((linkHref.indexOf("https://") != -1) || (linkHref.indexOf("http://") != -1))
					{
						if(!((linkHref.indexOf("aarhustech.itslearning.com") != -1) || (linkHref.indexOf("itslearning.eu") != -1) || (linkHref.indexOf("skolenet.aarhustech.dk") != -1)))
						{
							link.attr("target", "_blank");
						}
					}
				}
				
			});	
			
			var poweredby = $('body').find('img[src$="https://statics.itslearning.com/v3.46.1.71/images/powered_by_itslearning.png"]');
			
			poweredby.attr('src', otherimg);
			poweredby.css('width', "auto");
			poweredby.css('height', 24);
			
		}

	}
	else if(domain == "aarhustech")
	{
		var learningtext = $('body').find('div[title$="Skolens læringsmiljø for studerende"]');
		
		learningtext.html('<a href="https://aarhustech.itslearning.com/elogin/" ><img alt="Skolens l&#230;ringsmilj&#248; for studerende" src="http://www.ats.dk/images/Resume_145/its_learning.gif" ><br />it\'s loading</a>');
	}
});